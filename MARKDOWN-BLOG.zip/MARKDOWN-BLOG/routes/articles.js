const express= require('express')
const Article = require('./../models/article')
//const article = require('./../models/article')
const article = require('./../models/article')
const fs = require('fs');
const router = express.Router()

router.get('/new',(req,res)=>{
  res.render('articles/new',{article:new Article()})
})

router.get('/edit/:id',async(req,res)=>{
  const article= await Article.findById(req.params.id)
  res.render('articles/edit',{article:article})
})
router.get('/new',(req,res)=>{
  res.render('articles/new',{article:new Article()})
})
router.get('/:id',async(req,res)=>{
  const article = await Article.findById(req.params.id)
  if(!article) {
    return res.redirect('/');
  }
res.render('articles/show', { article:article})
});
 router.post('/',async(req,res, next)=>{
  req.article = new Article()
  next()
  },saveArticleAndRedirect('new')
  
 )
 router.post('/', async (req, res) => {
  const { title, description, markdown } = req.body;
  const file = req.file; // Uploaded file
  let fileContent = null;

  // Read the content of the uploaded file
  if (file) {
    try {
      fileContent = fs.readFileSync(file.path, 'utf-8');
      // Delete the temporary file after reading its content
      fs.unlinkSync(file.path);
    } catch (error) {
      console.error('Error reading file:', error);
      // Handle error appropriately
      return res.status(500).send('Error reading file');
    }
  }

  // Create a new Article instance and save it to the database
  const article = new Article({
    title: title,
    description: description,
    markdown: markdown,
    fileContent: fileContent // Store the file content in the 'fileContent' field
  });

  try {
    await article.save();
    res.redirect(`/articles/${article.id}`);
  } catch (error) {
    console.error('Error saving article:', error);
    res.render('articles/new', { article: article });
  }
});
 router.put('/:id',async(req,res,next)=>{
    req.article = await Article.findById(req.params.id)
    next()
 }, saveArticleAndRedirect('edit'))

 router.delete('/:id',async(req,res)=>{
  await Article.findByIdAndDelete(req.params.id)
 res.redirect('/')
 })
 
 function saveArticleAndRedirect(path){
    return async(req,res)=>{
      let article = req.article
      article.title = req.body.title
      article.description = req.body.description
      article.markdown = req.body.markdown
      try{
        article = await article.save()
        res.redirect(`/articles/${article.id}`)
      } catch(e){
        console.log(e)
       res.render('articles/new',{article:article})
    }
  }}
module.exports=router